<?php 
define('DBHOST', 'localhost'); 
define('DBNAME', 'cst499'); 
define('DBUSER', 'root'); 
define('DBPASS', 'vipersden');

ini_set('display_errors', 0); // Don't display errors in the browser
ini_set('log_errors', 1); // Log errors instead
ini_set('error_log', __DIR__ . '/error_log.txt'); // Where to save error logs