<?php
require_once __DIR__ . '/../bootstrap.php';

$controller = new WaitlistController();

$controller->handleRequest();