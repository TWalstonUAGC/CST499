<?php
require_once __DIR__ . '/../bootstrap.php';

$controller = new ClassesController();

$controller->handleAPIRequest();